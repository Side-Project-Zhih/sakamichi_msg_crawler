module.exports = {
  nogi: {
    1: {
      name: "秋元 真夏",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    2: {
      name: "生田 絵梨花",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    3: {
      name: "齋藤 飛鳥",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    4: {
      name: "高山 一実",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    5: {
      name: "樋口 日奈",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    6: {
      name: "星野 みなみ",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    7: {
      name: "松村 沙友理",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    8: {
      name: "和田 まあや",
      tag: "nogizaka-1",
      category: "乃木坂46-1期",
    },
    9: {
      name: "伊藤 純奈",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    10: {
      name: "北野 日奈子",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    11: {
      name: "新内 眞衣",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    12: {
      name: "鈴木 絢音",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    13: {
      name: "寺田 蘭世",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    14: {
      name: "堀 未央奈",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    15: {
      name: "山崎 怜奈",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    16: {
      name: "渡辺 みり愛",
      tag: "nogizaka-2",
      category: "乃木坂46-2期",
    },
    17: {
      name: "伊藤 理々杏",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    18: {
      name: "岩本 蓮加",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    19: {
      name: "梅澤 美波",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    20: {
      name: "大園 桃子",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    21: {
      name: "久保 史緒里",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    22: {
      name: "阪口 珠美",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    23: {
      name: "佐藤 楓",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    24: {
      name: "中村 麗乃",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    25: {
      name: "向井 葉月",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    26: {
      name: "山下 美月",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    27: {
      name: "吉田 綾乃ｸﾘｽﾃｨｰ",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    28: {
      name: "与田 祐希",
      tag: "nogizaka-3",
      category: "乃木坂46-3期",
    },
    29: {
      name: "遠藤 さくら",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    30: {
      name: "賀喜 遥香",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    31: {
      name: "掛橋 沙耶香",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    32: {
      name: "金川 紗耶",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    33: {
      name: "北川 悠理",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    34: {
      name: "黒見 明香",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    35: {
      name: "佐藤 璃果",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    36: {
      name: "柴田 柚菜",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    37: {
      name: "清宮 レイ",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    38: {
      name: "田村 真佑",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    39: {
      name: "筒井 あやめ",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    40: {
      name: "早川 聖来",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    41: {
      name: "林 瑠奈",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    42: {
      name: "松尾 美佑",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    43: {
      name: "矢久保 美緒",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    44: {
      name: "弓木 奈於",
      tag: "nogizaka-4",
      category: "乃木坂46-4期",
    },
    45: {
      name: "乃木坂46",
      tag: "nogizaka",
      category: "乃木坂46",
    },
  },
};
