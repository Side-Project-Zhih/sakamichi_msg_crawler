const GROUP = {
  nogi: {
    name: "乃木坂46",
  },
  sakura: {
    name: "櫻坂46",
  },
  hinata: {
    name: "日向坂46",
  },
};

module.exports = GROUP